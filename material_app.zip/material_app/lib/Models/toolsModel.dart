import 'package:material_app/components/images.dart';

class ToolsModel {
  String? Tname;
  int? Tprice;
  String? Timage;
  String? Tdescription;
  List? Tspecifications;
  List? Tapplications;

  ToolsModel(
      {this.Tname,
      this.Tprice,
      this.Tdescription,
      this.Tspecifications,
      this.Tapplications,
      this.Timage});


}
