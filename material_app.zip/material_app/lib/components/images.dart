class ImagesPaths {
  static var hammer = "assets/tools_icon/hammer.jpg";
  static var intro_image2 = "assets/images/intro_image2.jpg";
}
