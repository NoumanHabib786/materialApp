import 'package:flutter/cupertino.dart';
import 'package:sizer/sizer.dart';

SizedBox height(double height) {
  return SizedBox(
    height: height.h,
  );
}SizedBox width(double width) {
  return SizedBox(
    width: width.w,
  );
}